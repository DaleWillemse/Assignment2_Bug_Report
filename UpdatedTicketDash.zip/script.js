function openTicket() {
    document.getElementById("myTicket").style.display = "block";
  }
  
  function closeTicket() {
    document.getElementById("myTicket").style.display = "none";
  }
  localStorage.setItem('TitleAuthor',getElementById(TicketTitle));